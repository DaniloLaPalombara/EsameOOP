package it.univpm.ESAMEOOP;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OpenWeatherApplicationTests {

	@Test
	void contextLoads() {
	}

}
